export input="$1";
export num_proc="$2";
export N="$3";

make compile;
make run;
